var config = {};


config.email = 'deligoch@gmail.com'
config.password= 'deey5old4rhus_GEEN'

config.adminemail='deligoch@gmail.com'
config.url='http://boomadvertise.com/'
config.adminurl='http://boomadvertise.com/'
module.exports = config;


// MAIL_DRIVER=smtp
// MAIL_HOST=email-smtp.ap-south-1.amazonaws.com
// MAIL_PORT=587
// MAIL_ENCRYPTION=tls
// MAIL_USERNAME=AKIAREDTCB4G4N4SJUKF
// MAIL_PASSWORD=BFz7nWPoZc0jAYpUr5FkCeZsYpVYyTwjnuILc0vE3EaP
// host : smtp.gmail.com
// email port :587
// email : deligoch@gmail.com
// MAIL_ENCRYPTION : tls
// email_username : deligoch@gmail.com
// email pass : ifwmxlltkurvvctb
