import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promoter-account',
  templateUrl: './promoter-account.component.html',
  styleUrls: ['./promoter-account.component.css']
})
export class PromoterAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
